import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, Leaf, BookOpenCheck, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export default function HalaalHealWebsite() {
  return (
    <div className="bg-gradient-to-br from-[#f6f4ee] to-[#ded9cc] text-[#1e1e1e] font-serif">
      {/* Hero Section */}
      <section className="min-h-screen flex flex-col items-center justify-center text-center px-6 py-20">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6"
        >
          Halaal Heal
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2 }}
          className="text-xl md:text-2xl max-w-2xl mb-8"
        >
          Qur’an-Inspired Natural Remedies — Ancient Wisdom, Modern Healing
        </motion.p>
        <Button className="text-lg px-6 py-3 rounded-full bg-[#1e1e1e] text-white hover:bg-[#363636]">
          Join the Movement
        </Button>
      </section>

      {/* Our Vision */}
      <section className="grid md:grid-cols-2 gap-10 px-10 py-20 bg-[#ece7dd]">
        <div className="flex flex-col justify-center">
          <h2 className="text-4xl font-bold mb-6">Our Vision</h2>
          <p className="text-lg leading-relaxed">
            We believe true healing begins with purity. At Halaal Heal, our mission is to craft halal-certified remedies guided by the timeless knowledge of the Qur’an and Sunnah — starting with a fever remedy made of honey and cardamom.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1608315398428-087e0f7a2f57?fit=crop&w=900&q=80"
          alt="Natural Healing"
          className="rounded-2xl shadow-xl object-cover w-full h-[300px]"
        />
      </section>

      {/* Product Preview */}
      <section className="px-10 py-24 bg-[#f9f6f1]">
        <h2 className="text-4xl font-semibold text-center mb-16">What We're Building</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="rounded-2xl shadow-md hover:shadow-xl transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <Leaf className="w-10 h-10 mb-4 text-[#1e1e1e]" />
              <h3 className="text-2xl font-medium mb-2">FeverAid Tablets</h3>
              <p className="text-gray-700 mb-4">
                Made with honey & cardamom – ingredients praised in Revelation.
              </p>
              <Button variant="ghost" className="text-[#1e1e1e] hover:underline">
                Learn More <ArrowRight className="ml-2" />
              </Button>
            </CardContent>
          </Card>
          <Card className="rounded-2xl shadow-md hover:shadow-xl transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <BookOpenCheck className="w-10 h-10 mb-4 text-[#1e1e1e]" />
              <h3 className="text-2xl font-medium mb-2">Verse Verification</h3>
              <p className="text-gray-700 mb-4">
                Each bottle comes with a scannable verse that links to the Qur’anic source.
              </p>
            </CardContent>
          </Card>
          <Card className="rounded-2xl shadow-md hover:shadow-xl transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <Mail className="w-10 h-10 mb-4 text-[#1e1e1e]" />
              <h3 className="text-2xl font-medium mb-2">Join the Waitlist</h3>
              <p className="text-gray-700 mb-4">
                Be the first to experience Halaal Heal’s prophetic medicine line.
              </p>
              <Button className="text-white bg-[#1e1e1e] hover:bg-[#3c3c3c] rounded-full px-5 py-2">
                Sign Up
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#ded9cc] px-10 py-12 text-center text-sm text-[#4d4d4d]">
        <p className="mb-2">&copy; {new Date().getFullYear()} Halaal Heal. All rights reserved.</p>
        <p>Crafted with intention. Inspired by Revelation.</p>
      </footer>
    </div>
  );
}